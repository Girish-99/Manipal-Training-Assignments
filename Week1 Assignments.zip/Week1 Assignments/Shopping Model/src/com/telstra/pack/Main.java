package com.telstra.pack;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		System.out.println("Enter your Choice");
		System.out.println("1  : Add a new Product");
		System.out.println("2 : Display All Products");
		System.out.println("3: Search by Id");
		System.out.println("5 : exit");
		
		Scanner sc= new Scanner(System.in);
		int choice = sc.nextInt();
//		while(choice) {
//			case 1 :
//				System.out.println("add");
//				break;
//			case 2:{
//				break;
//			}
//			case 3 :{
//				break;
//			}
//			case 4:{
//				break;
//			}
//			default :
//			{
//				break;
//			}
//		}
		
	}

}

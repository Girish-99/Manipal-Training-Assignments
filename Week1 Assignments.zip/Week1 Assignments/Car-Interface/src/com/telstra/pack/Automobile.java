package com.telstra.pack;

public interface Automobile {

	String start();
	int increaseSpeed(int n);
	String stop();
	
}

package com.telstra.child;

public class Main {

	public static void main(String[] args) {
		Baby B1= new Baby(9);
		B1.babyHealth();

	}

}

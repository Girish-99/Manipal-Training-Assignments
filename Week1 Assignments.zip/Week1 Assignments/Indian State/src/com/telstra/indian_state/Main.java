package com.telstra.indian_state;

public class Main {

	public static void main(String[] args) {
//		String State= args[0];
		Information S1= new Information("Karnataka");
				Information.getPlace("Karnataka");

	}

}
